use airlines_data;

SELECT flight_id,
    TIMESTAMPDIFF(minute, scheduled_departure, actual_departure) AS avrgdelay
    FROM
    flights;

SELECT
    round(AVG(TIMESTAMPDIFF(MINUTE, scheduled_departure, actual_departure)),2) AS average_delay_minutes
FROM
    flights;